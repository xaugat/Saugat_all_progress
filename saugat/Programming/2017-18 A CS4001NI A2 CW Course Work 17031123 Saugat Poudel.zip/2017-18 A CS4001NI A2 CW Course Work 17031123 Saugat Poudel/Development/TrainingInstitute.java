/**
 * 
 * @author (Saugat Poudel)
 * @id NP01CP4A170093
 */

import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class TrainingInstitute implements ActionListener //here training institute class is made and the Action listener method is implemented to call them. 
{
    JLabel ProfessionalCourse,ProfessionalDescription,ProfessionalInstructor,
    ProfessionalCourseDuration,ProfessionalDailyHour,ProfessionalFee,ProfessionalDownPayment,ProfessionalCourseNo,
    ProfessionalStudentName,ProfessionalEnrollDate,ProfessionalRoom,CertificationCourse,CertificationLine,CertificationDescription,
    CertificationInstructor,CertificationCourseDuration,CertificationDailyHour,CertificationFee,
    CertificationDownPayment,CertificationCourseNo,CertificationStudentName,CertificationStartDate,
    CertificationExamDate,CertificationExamCenter,CertificationAwardedBy,CertificationValidDuration;

    JTextField ProfessionalDescriptionBox, ProfessionalInstructorBox,ProfessionalCourseDurationBox,ProfessionalCourseNoBox,
    ProfessionalDailyHourBox,ProfessionalFeeBox,ProfessionalDownPaymentBox,ProfessionalStudentNameBox,ProfessionalEnrollDateBox,
    ProfessionalRoomBox,CertificationDescriptionBox,
    CertificationInstructorBox,CertificationCourseDurationBox,CertificationDailyHourBox,CertificationFeeBox,
    CertificationDownPaymentBox,CertificationCourseNoBox,CertificationStudentNameBox,CertificationStartDateBox,
    CertificationExamDateBox,CertificationExamCenterBox,CertificationAwardedByBox,CertificationValidDurationBox;

    JButton ProfessionalAdd,ProfessionalComplete,ProfessionalEnrollStudent,CertificationAdd,CertificationEnrollStudent,
    CertificationClear,CertificationDisplayAll;

    JSeparator SeparatorOne,SeparatorTwo; 
    JFrame f;
    private ArrayList <Course> list_=new ArrayList<Course>();//keeping the arraylist in private so that it cannot access other class except it's own child classes.
    private int i=0;
    public void TrainingForm(){ //new method is made for GUI design.
        f=new JFrame("Training Form");
        ProfessionalCourse= new JLabel("Professional Course");
        ProfessionalCourse.setBounds (10,10,150,20);
        f.add(ProfessionalCourse);

        SeparatorOne= new JSeparator();
        SeparatorOne.setBounds (10,30,1000,3);
        f.add(SeparatorOne);

        ProfessionalDescription=new JLabel ("Course Name:");
        ProfessionalDescription.setBounds (20,50,80,40);
        f.add (ProfessionalDescription);

        ProfessionalDescriptionBox=new JTextField();
        ProfessionalDescriptionBox.setBounds (120,60,450,20);
        f.add(ProfessionalDescriptionBox);

        ProfessionalInstructor=new JLabel ("Instructor:");
        ProfessionalInstructor.setBounds (20,70,80,50);
        f.add(ProfessionalInstructor);

        ProfessionalInstructorBox=new JTextField();
        ProfessionalInstructorBox.setBounds (120,85,450,20);
        f.add(ProfessionalInstructorBox);

        ProfessionalCourseDuration=new JLabel ("Total Hours:");
        ProfessionalCourseDuration.setBounds (20,95,150,70);
        f.add(ProfessionalCourseDuration);

        ProfessionalCourseDurationBox=new JTextField();
        ProfessionalCourseDurationBox.setBounds (120,118,110,20);
        f.add(ProfessionalCourseDurationBox);

        ProfessionalDailyHour=new JLabel ("Daily Hour:");
        ProfessionalDailyHour.setBounds (250,95,200,70);
        f.add(ProfessionalDailyHour);

        ProfessionalDailyHourBox=new JTextField();
        ProfessionalDailyHourBox.setBounds (350,118,220,20);
        f.add(ProfessionalDailyHourBox);

        ProfessionalFee=new JLabel ("Fee:");
        ProfessionalFee.setBounds (20,120,150,70);
        f.add(ProfessionalFee);

        ProfessionalFeeBox=new JTextField();
        ProfessionalFeeBox.setBounds (120,145,110,20);
        f.add(ProfessionalFeeBox);

        ProfessionalAdd=new JButton("Add");
        ProfessionalAdd.setBounds (480,170,100,20);
        f.add(ProfessionalAdd);

        ProfessionalCourseNo=new JLabel ("CourseNo.#:");
        ProfessionalCourseNo.setBounds (20,190,80,40);
        f.add(ProfessionalCourseNo);

        ProfessionalCourseNoBox=new JTextField();
        ProfessionalCourseNoBox.setBounds (120,200,450,20);
        f.add(ProfessionalCourseNoBox);

        ProfessionalStudentName=new JLabel ("Student Name:");
        ProfessionalStudentName.setBounds (20,220,100,40);
        f.add(ProfessionalStudentName);

        ProfessionalStudentNameBox=new JTextField();
        ProfessionalStudentNameBox.setBounds (120,230,450,20);
        f.add(ProfessionalStudentNameBox);

        JLabel ProfessionalEnrollDate=new JLabel ("Enroll Date:");
        ProfessionalEnrollDate.setBounds (20,240,150,70);
        f.add(ProfessionalEnrollDate);

        ProfessionalEnrollDateBox=new JTextField();
        ProfessionalEnrollDateBox.setBounds (120,260,110,20);
        f.add(ProfessionalEnrollDateBox);

        ProfessionalRoom= new JLabel ("Room#:");
        ProfessionalRoom.setBounds (250,240,200,70);
        f.add(ProfessionalRoom);

        ProfessionalDownPayment=new JLabel ("Down Payment:");
        ProfessionalDownPayment.setBounds (20,270,100,70);
        f.add(ProfessionalDownPayment);

        ProfessionalDownPaymentBox=new JTextField();
        ProfessionalDownPaymentBox.setBounds (120,290,110,20);
        f.add(ProfessionalDownPaymentBox);

        ProfessionalRoomBox=new JTextField();
        ProfessionalRoomBox.setBounds (300,260,270,20);
        f.add(ProfessionalRoomBox);

        ProfessionalComplete=new JButton("Complete");
        ProfessionalComplete.setBounds (280,290,130,20);
        f.add(ProfessionalComplete);

        ProfessionalEnrollStudent=new JButton("Enroll Student");
        ProfessionalEnrollStudent.setBounds (420,290,160,20);
        f.add(ProfessionalEnrollStudent);

        CertificationCourse= new JLabel ("Certification Course");
        CertificationCourse.setBounds (10,330,150,20);
        f.add(CertificationCourse);

        SeparatorTwo= new JSeparator();
        SeparatorTwo.setBounds (10,350,1000,3);
        f.add(SeparatorTwo);

        CertificationDescription=new JLabel ("Course Name:");
        CertificationDescription.setBounds (20,350,80,40);
        f.add (CertificationDescription);

        CertificationDescriptionBox=new JTextField();
        CertificationDescriptionBox.setBounds (120,360,450,20);
        f.add(CertificationDescriptionBox);

        CertificationInstructor=new JLabel ("Instructor:");
        CertificationInstructor.setBounds (20,380,80,50);
        f.add(CertificationInstructor);

        CertificationInstructorBox=new JTextField();
        CertificationInstructorBox.setBounds (120,390,450,20);
        f.add(CertificationInstructorBox);

        CertificationCourseDuration=new JLabel ("Total Hours:");
        CertificationCourseDuration.setBounds (20,400,150,70);
        f.add(CertificationCourseDuration);

        CertificationCourseDurationBox=new JTextField();
        CertificationCourseDurationBox.setBounds (120,420,110,20);
        f.add(CertificationCourseDurationBox);

        CertificationAwardedBy=new JLabel ("AwardedBy:");
        CertificationAwardedBy.setBounds (270,400,200,70);
        f.add(CertificationAwardedBy);

        CertificationAwardedByBox=new JTextField();
        CertificationAwardedByBox.setBounds (350,420,220,20);
        f.add(CertificationAwardedByBox);

        CertificationFee=new JLabel ("Fee:");
        CertificationFee.setBounds (20,430,150,70);
        f.add(CertificationFee);

        CertificationFeeBox=new JTextField();
        CertificationFeeBox.setBounds (120,450,110,20);
        f.add(CertificationFeeBox);

        CertificationValidDuration=new JLabel ("ValidDuration:");
        CertificationValidDuration.setBounds (250,430,200,70);
        f.add(CertificationValidDuration);

        CertificationValidDurationBox=new JTextField();
        CertificationValidDurationBox.setBounds (350,450,220,20);
        f.add(CertificationValidDurationBox);

        CertificationAdd=new JButton("Add");
        CertificationAdd.setBounds (480,475,100,20);
        f.add(CertificationAdd);

        CertificationCourseNo=new JLabel ("CourseNo.#:");
        CertificationCourseNo.setBounds (20,490,80,40);
        f.add(CertificationCourseNo);

        CertificationCourseNoBox=new JTextField();
        CertificationCourseNoBox.setBounds (120,500,450,20);
        f.add(CertificationCourseNoBox);

        CertificationStudentName=new JLabel ("Student Name:");
        CertificationStudentName.setBounds (20,510,100,40);
        f.add(CertificationStudentName);

        CertificationStudentNameBox=new JTextField();
        CertificationStudentNameBox.setBounds (120,525,450,20);
        f.add(CertificationStudentNameBox);

        CertificationStartDate=new JLabel ("Start Date:");
        CertificationStartDate.setBounds (20,525,150,70);
        f.add(CertificationStartDate);

        CertificationStartDateBox=new JTextField();
        CertificationStartDateBox.setBounds (120,550,110,20);
        f.add(CertificationStartDateBox);

        CertificationExamDate=new JLabel ("Exam Date:");
        CertificationExamDate.setBounds (250,525,200,70);
        f.add(CertificationExamDate);

        CertificationExamDateBox=new JTextField();
        CertificationExamDateBox.setBounds (320,550,250,20);
        f.add(CertificationExamDateBox);

        CertificationExamCenter=new JLabel ("ExamCenter:");
        CertificationExamCenter.setBounds (20,565,80,40);
        f.add(CertificationExamCenter);

        CertificationExamCenterBox=new JTextField();
        CertificationExamCenterBox.setBounds (120,575,450,20);
        f.add(CertificationExamCenterBox);

        CertificationEnrollStudent=new JButton("Enroll Student");
        CertificationEnrollStudent.setBounds (460,645,120,20);
        f.add(CertificationEnrollStudent);

        CertificationClear=new JButton("Clear");
        CertificationClear.setBounds (360,670,120,20);
        f.add(CertificationClear);

        CertificationDisplayAll=new JButton("Display All");
        CertificationDisplayAll.setBounds (460,670,120,20);
        f.add(CertificationDisplayAll);

        f.setSize(600,1000);
        f.setLayout(null);
        f.setVisible(true);
        ProfessionalAdd.addActionListener(this);// here action listener for professionaladd method is made.
        CertificationAdd.addActionListener(this);
        ProfessionalComplete.addActionListener(this);
        ProfessionalEnrollStudent.addActionListener(this);
        CertificationEnrollStudent.addActionListener(this);
        CertificationClear.addActionListener(this);
        CertificationDisplayAll.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e){//override the actionperform() method from action perform interface.
        if (e.getSource()==ProfessionalAdd){
            addToProfessional();
        }
        else if(e.getSource()==CertificationAdd){
            addToCertification();
        }
        else if(e.getSource()==ProfessionalComplete){
            CompleteProfessional();
        }
        else if(e.getSource()==ProfessionalEnrollStudent){
            ProfessionalEnrollStudent();
        }
        else if(e.getSource()==CertificationEnrollStudent){
            CertificationEnrollStudent();

        }
        else if(e.getSource()==CertificationClear){
            ClearAll();
        }
        else if(e.getSource()==CertificationDisplayAll){
            displayAll();
        }
    }

    public void addToProfessional(){// this method is made to work add button of professional course
        try{
            String courseName=ProfessionalDescriptionBox.getText();
            String instructorName=ProfessionalInstructorBox.getText();
            int totalHoursToComplete=Integer.parseInt(ProfessionalCourseDurationBox.getText());
            int dailyHour =Integer.parseInt(ProfessionalDailyHourBox.getText());
            int courseFee=Integer.parseInt(ProfessionalFeeBox.getText());
            if (courseName.equals ("")){ // here if the coursename is not inserted in the box then below message will be shown.
                JOptionPane.showMessageDialog(f,"Course Name not inserted for Professional");
            }else if
            (instructorName.equals("")){ //here if the instructor is not inserted in the box then below message will be shown
                JOptionPane.showMessageDialog(f,"Instructor Name not inserted for Professional");
            }else if
            (dailyHour<=0){ 
                JOptionPane.showMessageDialog(f,"daily hour must be more than Zero");
            }else if
            (dailyHour>24){ 
                JOptionPane.showMessageDialog(f,"daily hour must be less than 24hr");
            }else if
            (dailyHour>totalHoursToComplete){ 
                JOptionPane.showMessageDialog(f,"daily hour must be less than total hour");
            }else if
            (courseFee<=0){ 
                JOptionPane.showMessageDialog(f,"Course Fee must be more than Zero");
            }else if 
            (totalHoursToComplete<=0){ 
                JOptionPane.showMessageDialog(f,"totalHours must be more than Zero");
            }else{
                ProfessionalClass ProfessionalObj=new ProfessionalClass(courseName, instructorName,dailyHour,totalHoursToComplete,courseFee);//here the object of professional class is made.
                list_.add(ProfessionalObj);// adding the professional class object in list
                JOptionPane.showMessageDialog(f,"SuccessFully Added For Professional Course");

            }

        }catch(NumberFormatException e){// this will give a error message if the value is not inserted in the box.
            JOptionPane.showMessageDialog(f,"please insert a authentic value"+e.getMessage(),"ERROR",JOptionPane.INFORMATION_MESSAGE);
        }
        catch(NullPointerException e)
        { 
            JOptionPane.showMessageDialog(f,e.getMessage(),"Error!! No input.",JOptionPane.ERROR_MESSAGE);  

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(f,"Error:"+e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void addToCertification(){// this method is made to work add button which will add the values of student of crtification course. 
        try{
            String courseName=CertificationDescriptionBox.getText();
            String instructorName=CertificationInstructorBox.getText();
            int totalHoursToComplete=Integer.parseInt(CertificationCourseDurationBox.getText());
            int courseFee=Integer.parseInt(CertificationFeeBox.getText());
            String certificateAwardedBy =(CertificationAwardedByBox.getText());
            String validTill =(CertificationValidDurationBox.getText());
            if (courseName.equals ("")){
                JOptionPane.showMessageDialog(f,"Description not inserted for Certification");// this is the condition to set the limitation of input.
            }else if
            (instructorName.equals ("")){
                JOptionPane.showMessageDialog(f,"Instructor Name not inserted for Certification");
            }else if
            (certificateAwardedBy.equals ("")){
                JOptionPane.showMessageDialog(f,"AwardedBy not inserted for Certification");
            }else if
            (validTill.equals ("")){
                JOptionPane.showMessageDialog(f,"ValidDuration not inserted for Certification");
            }else if
            (courseFee<=0){ 
                JOptionPane.showMessageDialog(f,"Course Fee must be more than Zero");
            }else if 
            (totalHoursToComplete<=0){ 
                JOptionPane.showMessageDialog(f,"totalHours must be more than Zero");
            }else{
                CertificationClass CertificationObj= new CertificationClass(courseName,instructorName,totalHoursToComplete,courseFee,certificateAwardedBy,validTill);// certification class object is made.
                list_.add(CertificationObj);// certification object is added to list.
                JOptionPane.showMessageDialog(f,"SuccessFully Added For Certification Course");

            }

        }catch(NumberFormatException e){ 
            JOptionPane.showMessageDialog(f,"Please input authentic value "+e.getMessage(),"Error!!",JOptionPane.INFORMATION_MESSAGE);  
        }catch (Exception e){
            JOptionPane.showMessageDialog(f, e.getMessage(),"Error!! Message", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void CompleteProfessional(){// this method is made to work complete button after the student enroll in the particular course.
        try{
            int courseNo=Integer.parseInt(ProfessionalCourseNoBox.getText());
            if(list_.get(courseNo) instanceof ProfessionalClass){// checking either it belongs to professional class or not.
                ProfessionalClass ProfessionalObj=(ProfessionalClass)list_.get(courseNo);
                ProfessionalObj.getStartedStatus();
                if(ProfessionalObj.getStartedStatus()==false){
                    JOptionPane.showMessageDialog(f,"Course Not Started Yet","WARNING",JOptionPane.WARNING_MESSAGE);
                }else{
                    if(courseNo>=list_.size()||courseNo<0){// course number and it's list index is defined.
                        JOptionPane.showMessageDialog(f,"Not valid Course Number");
                    }else{
                        if(list_.get(courseNo) instanceof ProfessionalClass){// checking in professional class
                            ProfessionalClass ProfessionalObjnew=(ProfessionalClass)list_.get(courseNo);// making object of professional class
                            ProfessionalObjnew.courseCompletion();
                            JOptionPane.showMessageDialog(f,"SucessFully Completed","Enrollment Description",JOptionPane.INFORMATION_MESSAGE);

                        }else{
                            JOptionPane.showMessageDialog(f,"Not available Course Number");
                        }
                    }
                }
            }
        }catch(NumberFormatException e){ 
            JOptionPane.showMessageDialog(f,"Please input authentic value "+e.getMessage(),"Error!!",JOptionPane.INFORMATION_MESSAGE);  
        }catch (Exception e){
            JOptionPane.showMessageDialog(f, e.getMessage(),"Error!! Message", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void ProfessionalEnrollStudent(){// this method is made to work enroll button of professional course.
        try{
            int courseNo=Integer.parseInt(ProfessionalCourseNoBox.getText());
            String studentName=ProfessionalStudentNameBox.getText();
            String enrolDate=ProfessionalEnrollDateBox.getText();
            int downPayment=Integer.parseInt(ProfessionalDownPaymentBox.getText());  
            String roomNo=ProfessionalRoomBox.getText();
            int courseFee=Integer.parseInt(ProfessionalFeeBox.getText());
            if (courseNo>=list_.size()||courseNo<0){// list size is kept in the condition to know about the particular course.
                JOptionPane.showMessageDialog(f,"Not valid Course Number");
            }else if
            (studentName.equals ("")){
                JOptionPane.showMessageDialog(f,"Student Name not inserted for Professional");//condition to display the message when no value is added.
            }else if
            (enrolDate.equals ("")){
                JOptionPane.showMessageDialog(f,"Enroll Date not inserted for Professional");
            }else if
            (downPayment<=0){
                JOptionPane.showMessageDialog(f,"Down payment must be more than Zero");
            }else if
            (roomNo.equals ("")){
                JOptionPane.showMessageDialog(f,"Room number not inserted for Professional");
            }else if(courseFee<=downPayment){
                JOptionPane.showMessageDialog(f,"DownPayment cannot be greater than or equal with fee.");

            }else{
                if(list_.get(courseNo) instanceof ProfessionalClass){// checking the course in professional class
                    ProfessionalClass ProfessionalObj=(ProfessionalClass)list_.get(courseNo);// making an object of professional class
                    ProfessionalObj.enrolStudent(studentName,enrolDate,downPayment,roomNo);// calling the parameter
                    JOptionPane.showMessageDialog(f,"SucessFully Enrolled in Professional Course","Enrollment Description",JOptionPane.INFORMATION_MESSAGE);
                }else{
                    JOptionPane.showMessageDialog(f,"You cannot Enroll in this Course","About Enrollment",JOptionPane.INFORMATION_MESSAGE);
                }
            }

        }catch(NumberFormatException e){ // number format exception 
            JOptionPane.showMessageDialog(f,"Please input authentic value "+e.getMessage(),"Error!!",JOptionPane.INFORMATION_MESSAGE);  
        }catch (Exception e){
            JOptionPane.showMessageDialog(f, e.getMessage(),"Error!! Message", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void CertificationEnrollStudent(){// this method is made to work enroll button in certification course.
        try{
            int courseNo=Integer.parseInt(CertificationCourseNoBox.getText());
            String studentName=CertificationStudentNameBox.getText();
            String startDate=CertificationStartDateBox.getText();
            String examDate=CertificationExamDateBox.getText();
            String examCenter=(CertificationExamCenterBox.getText());  

            if(courseNo>=list_.size()||courseNo<0){// checking the course no either belongs to the particular course or not.
                JOptionPane.showMessageDialog(f,"Not valid Course Number");
            }else if
            (studentName.equals ("")){
                JOptionPane.showMessageDialog(f,"Student Name not inserted for Certification");// condition given when no value is inserted.
            }else if
            (startDate.equals ("")){
                JOptionPane.showMessageDialog(f,"Start Date not inserted for Certification");
            }else if
            (examDate.equals ("")){
                JOptionPane.showMessageDialog(f,"Exam Date not inserted for Certification");
            }else{
                if(list_.get(courseNo) instanceof CertificationClass){// checking the course number in certification class
                    CertificationClass CertificationObj=(CertificationClass)list_.get(courseNo);// making object of certification class to call parameter.
                    CertificationObj.enrollingStudent(studentName,startDate,examDate,examCenter);
                    JOptionPane.showMessageDialog(f,"SucessFully Enrolled in Certification Course","Enrollment Description",JOptionPane.INFORMATION_MESSAGE);
                }else{
                    JOptionPane.showMessageDialog(f,"You cannot Enroll in this Course","About Enrollment",JOptionPane.INFORMATION_MESSAGE);
                }
            }

        }catch(NumberFormatException e){ 
            JOptionPane.showMessageDialog(f,"Please input authentic value "+e.getMessage(),"Error!!",JOptionPane.INFORMATION_MESSAGE);  
        }catch (Exception e){
            JOptionPane.showMessageDialog(f, e.getMessage(),"Error!! Message", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void ClearAll(){//this method is made to work clear button when all you need to add value for new student and clear the older one, this will clear all the value from GUI.
        ProfessionalDescriptionBox.setText("");
        ProfessionalInstructorBox.setText("");
        ProfessionalCourseDurationBox.setText("");
        ProfessionalCourseNoBox.setText("");
        ProfessionalDailyHourBox.setText("");
        ProfessionalFeeBox.setText("");
        ProfessionalDownPaymentBox.setText("");
        ProfessionalStudentNameBox.setText("");
        ProfessionalEnrollDateBox.setText("");
        ProfessionalRoomBox.setText("");
        CertificationDescriptionBox.setText("");
        CertificationInstructorBox.setText("");
        CertificationCourseDurationBox.setText("");
        CertificationFeeBox.setText("");
        CertificationAwardedByBox.setText("");
        CertificationValidDurationBox.setText("");
        CertificationCourseNoBox.setText("");
        CertificationStudentNameBox.setText("");
        CertificationStartDateBox.setText("");
        CertificationExamDateBox.setText("");
        CertificationExamCenterBox.setText("");
        JOptionPane.showMessageDialog(f,"Value Cleared");

    }

    public void displayAll(){// this method is made to display all the values in a text file and to give suitable output.
        if(list_.isEmpty()){
            JOptionPane.showMessageDialog(f,"No value inserted","Error!!",JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            for(Course CourseObj:list_){
                if(CourseObj instanceof ProfessionalClass){// checking the values in professional class
                    System.out.println("_______________________________Professional Course_________________________________________________________");
                    ((ProfessionalClass)CourseObj).display();
                    JOptionPane.showMessageDialog(f,"Value Displayed","MESSAGE!!",JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("___________________________________________________________________________________________________________");
                }else if (CourseObj instanceof CertificationClass){// checking the values in certification class
                    System.out.println("_______________________________Certification Course__________________________________________________________");
                    ((CertificationClass)CourseObj).display();
                    System.out.println("___________________________________________________________________________________________________________");
                    JOptionPane.showMessageDialog(f,"Value Displayed","MESSAGE!!",JOptionPane.INFORMATION_MESSAGE);
                }

            }

        }
    }

    public static void main (String args[]){// this is the main method of all the method.
        TrainingInstitute a=new TrainingInstitute();// calling training institute method here.
        a.TrainingForm();

    }
}

