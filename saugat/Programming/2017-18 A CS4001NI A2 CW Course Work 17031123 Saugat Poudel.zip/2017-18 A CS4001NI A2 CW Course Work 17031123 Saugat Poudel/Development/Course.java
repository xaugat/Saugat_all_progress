/**
 *write a description of class Course here.
 * 
 * @author (Saugat Poudel)
 * @id NP01CP4A170093
 */

public class Course{ //this is the parent class
    //this is a instance variable
    public String courseName;
    public String instructorName;
    public int totalHoursToComplete;
    public String studentName;

    //calling constructor
    public Course(String courseName,String instructorName, int totalHoursToComplete){
        this.courseName=courseName;
        this.instructorName=instructorName;
        this.totalHoursToComplete=totalHoursToComplete;   
        studentName="";

    }

    //these are the getter method they returns its value
    public String getCourseName(){
        return courseName;
    }

    public String getInstructorName(){
        return instructorName;
    }

    public int getTotalHoursToComplete(){
        return totalHoursToComplete;
    }

    public String getStudentName(){
        return studentName;
    }
    // these are the setter method they give new value
    public void setStudentName(String studentName){
        this.studentName=studentName;
    }
    //this is the display method this display the total value
    public void display(){
        if (!studentName.equals  ("")){// this is the conditional statement
            System.out.println("the student name is: "+studentName);
        }
        System.out.println("the course name is: "+courseName);
        System.out.println("the instructor name is: "+instructorName);
        System.out.println("the total hours is: "+totalHoursToComplete);
    }
}



