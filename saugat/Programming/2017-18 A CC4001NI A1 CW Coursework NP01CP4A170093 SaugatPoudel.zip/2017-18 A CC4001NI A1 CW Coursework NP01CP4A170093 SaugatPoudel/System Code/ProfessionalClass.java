/**
 *write a description of class Professional here.
* 
* @author (Saugat Poudel)
* @id NP01CP4A170093
*/
public class ProfessionalClass extends Course{// here professional class is extended to course class
    //these are the values for professional class
    private int courseFee;
    private String enrolDate;
    private String roomNo;
    private int dailyHour;
    private int downPayment;
    private boolean startedStatus;
    private boolean CourseCompleted;
//parameter is passed
public ProfessionalClass (String courseName, String instructorName, int courseFee, int totalHoursToComplete, int dailyHour){
    super (courseName,instructorName,totalHoursToComplete);//here super class is called with a parameters
    //these are the keywords to get new value
    this.courseFee=courseFee;
    this.dailyHour=dailyHour;
    this.enrolDate="";
    this.roomNo="";
    this.downPayment=0;
    this.CourseCompleted=false;
    this.startedStatus=false;

}
// these are the getter method for professional class and also the value is returned
public int getCoursefee()
{
    return courseFee;
}
public String getEnrolDate(){
    return enrolDate;
}
public String getRoomNo(){
    return roomNo;
}
public int getDailyHour(){
    return dailyHour;
}
public int getDownPayment(){
    return downPayment;
}
public boolean getcourseCompleted(){
    return CourseCompleted;
}
public boolean getStartedStatus(){
    return startedStatus;
}
// these are the setter method with keyword to set new value
public void setCourseFee(int courseFee){
    this.courseFee= courseFee;
}
public void setDailyHour(int dailyHour){
    this.dailyHour=dailyHour;
}
public void enrolStudent(String studentName, String enrolDate, int downPayment, String roomNo){
    if (startedStatus==true){// this is the conditional statement
        System.out.println("Dear" +getInstructorName()+ "your class has been already started, please go to room no" +getRoomNo());
    }else{
        super.setStudentName(studentName);
        this.enrolDate = enrolDate;
        this.downPayment=downPayment;
        this.roomNo=roomNo;
        startedStatus=true;
        CourseCompleted=false;
    }
}
public void courseCompletion(){// this is the void method 
    if (CourseCompleted==true){
        System.out.println("Dear" +getInstructorName()+ "your Course has been completed");
    }else{
        setStudentName("");
        downPayment=0;
        enrolDate = "";
        startedStatus=false;
        CourseCompleted=true;
        
    }
}
public void print(){// this is void method
        System.out.println("The student's name is: "+getStudentName());
        System.out.println("The instructor's name is: "+getInstructorName());
        System.out.println("The room number is: "+getRoomNo());
}
public void display(){// here all the values are displayed and printed
    super.display();
    if(startedStatus==true){
        System.out.println("The student's name is: "+getStudentName());
        System.out.println("Dearyour course has been started"+getStartedStatus());
        System.out.println("your enroll date is" +getEnrolDate());
        System.out.println("your DownPayment is" +getDownPayment());
    }
        
}
}
        
        
        
        
        

    



    
 
    