/**
 *write a description of class Certification here.
* 
* @author (Saugat Poudel)
* @id NP01CP4A170093
*/
public class CertificationClass extends Course{// here course class is extended to certification class and values are kept
    private int courseFee;
    private String startDate;
    private String examDate;
    private String examCentre;
    private String certificateAwardedBy;
    private String validTill;
    private boolean startedStatus;
    public CertificationClass(String courseName, String instructorName, int totalHoursToComplete, int courseFee, String certificateAwardedBy, String validTill){
    super(courseName,instructorName,totalHoursToComplete);// here super class is called
    // this is the keyword to add new value
    this.courseFee=courseFee;
    this.certificateAwardedBy=certificateAwardedBy;
    this.validTill=validTill;
    this.startDate=("");
    this.examDate=("");
    this.examCentre=("");
    this.startedStatus=false;
}
//these are the getter method which also return values
public int getCourseFee (){
    return courseFee;
}
public String getStartDate (){
    return startDate;
}
public String getExamDate(){
    return examDate;
}
public String getExamCentre(){
    return examCentre;
}
public String getCertificateAwardedBy(){
    return certificateAwardedBy;
}
public String getValidTill(){
    return validTill;
}

public void change(int courseFee){// this void method is used to change the value
    if(startedStatus==false){// this is the conditional statement
        this.courseFee=courseFee;
    }else{
        System.out.println("It is not Possible to change the Course fee");
        
    }
}
public void enrollingStudent(String studentName, String startDate, String examDate, String examCentre){// this is void method with some parameters
    if(startedStatus==false){// this is the conditional statement
        setStudentName(studentName);
        startedStatus=true;
        this.examDate=examDate;
        this.examCentre=examCentre;

    }else{
        System.out.println("your course has been already started since"+getStartDate());
    }
    this.studentName=studentName;
    this.startDate=startDate;
}
    
public void display(){// here all the values are keyword
    super.display();// super class is called to display all the value
    if (startedStatus==true){// this is conditional statement
        System.out.println("the student name is:"+getStudentName());
        System.out.println("the start date of course is"+getStartDate());
        System.out.println("the exam date is: "+getExamDate());
        System.out.println("the examCentre is: "+getExamCentre());
        System.out.println("the Valid date is: "+getValidTill());
        System.out.println("the certification is awarded by: "+getCertificateAwardedBy());
    
    }
}
}





    
 