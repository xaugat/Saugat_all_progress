<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "company";
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
		echo "connection failed....";
	} 

		$comp_sql = "SELECT * FROM company_details";
		$result_comp = $conn->query($comp_sql);

		$ceo_sql = "SELECT * FROM ceo";
		$result_ceo = $conn->query($ceo_sql);

		$gen_sql = "SELECT * FROM general_department";
		$result_gen = $conn->query($gen_sql);

		$proManager_sql = "SELECT * FROM project_manager";
		$result_proManager = $conn->query($proManager_sql);

		$tech_sql = "SELECT * FROM technical_department";
		$result_tech = $conn->query($tech_sql);
				

		$xml=new DomDocument('1.0');
		$xml->formatOutput=true;
		/*create element using createElement()
		append child to parent using appendChild()*/

			$company=$xml->createElement("mycompany");
			$xml->appendChild($company);

			


		while($row1 = mysqli_fetch_assoc($result_comp)) {

			$cominfo = $xml->createElement("company_info");
			$company->appendChild($cominfo);
			
			
			$comp_name=$xml->createElement("company_name", $row1["Company_Name"]);
			$comp_add=$xml->createElement("company_address", $row1["Company_Address"]);
			$comp_tel=$xml->createElement("company_telephone_number", $row1["Company_Telphone_Number"]);
			$comp_mob=$xml->createElement("company_mobile_number", $row1["Company_Mobile_number"]);
			$comp_web=$xml->createElement("company_website", $row1["Company_Website"]);
			$comp_img=$xml->createElement("company_image", $row1["Company_Image"]);

			$cominfo->appendChild($comp_name);
			$cominfo->appendChild($comp_add);
			$cominfo->appendChild($comp_tel);
			$cominfo->appendChild($comp_mob);
			$cominfo->appendChild($comp_web);
			$cominfo->appendChild($comp_img);
		}

			$comp_ceo=$xml->createElement("CEO");
			$company->appendChild($comp_ceo);
			$info = $xml->createElement("info");
			$comp_ceo->appendChild($info);

		while($row2 = mysqli_fetch_assoc($result_ceo)) {
			

			$ceo_name=$xml->createElement("ceo_name", $row2["name"]);
			$ceo_add=$xml->createElement("ceo_address", $row2["address"]);
			$ceo_phn=$xml->createElement("ceo_phone", $row2["phone"]);
			$ceo_mail=$xml->createElement("ceo_mail", $row2["email"]);
			$ceo_ceoimg=$xml->createElement("ceoimg", $row2["ceo_image"]);
			
			$info->appendchild($ceo_name);
			$info->appendchild($ceo_add);
			$info->appendchild($ceo_phn);
			$info->appendchild($ceo_mail);
			$info->appendchild($ceo_ceoimg);
			
				
		}
		while($row3 = mysqli_fetch_assoc($result_gen)) {
			$comp_gen=$xml->createElement("general_department");
			$comp_gen->setAttribute("id",$row3["dep.id"]);
			$comp_ceo->appendChild($comp_gen);

			$gen_name=$xml->createElement("gen_name", $row3["dep.name"]);
			$gen_desc=$xml->createElement("gen_description", $row3["dep.description"]);
			
			$comp_gen->appendchild($gen_name);
			$comp_gen->appendchild($gen_desc);
				
		}



			while($row4 = mysqli_fetch_assoc($result_proManager)) {
			$comp_proManager=$xml->createElement("project_manager");
			$comp_ceo->appendChild($comp_proManager);
			$pminfo = $xml->createElement("pminfo");
			$comp_proManager->appendChild($pminfo);

			$proManager_name=$xml->createElement("pmname", $row4["name"]);
			$proManager_phn=$xml->createElement("pmphone", $row4["phone"]);
			$proManager_add=$xml->createElement("pmaddress", $row4["address"]);
			$proManager_manimg=$xml->createElement("managerimg", $row4["manager_img"]);

			
			$pminfo->appendchild($proManager_name);
			$pminfo->appendchild($proManager_phn);
			$pminfo->appendchild($proManager_add);
			$pminfo->appendchild($proManager_manimg);
			
				

		}
		while($row = mysqli_fetch_assoc($result_tech)) {
			$comp_tech=$xml->createElement("technical_department");
			$comp_tech->setAttribute("id",$row["Dep.ID"]);
			//$company->appendChild($comp_tech);
			$comp_proManager->appendChild($comp_tech);


			$tech_name=$xml->createElement("tech_name", $row["Dep.Name"]);
			$tech_leadname=$xml->createElement("tech_team_leader", $row["team_leader"]);
			$tech_desc=$xml->createElement("tech_description", $row["Dep.Description"]);
			
			$comp_tech->appendchild($tech_name);
			$comp_tech->appendchild($tech_leadname);
			$comp_tech->appendchild($tech_desc);
			$comp_tech->appendchild($tech_leadname);
				


		}		

		echo "<xmp>".$xml->saveXML()."</xmp>";
		$xml->save('catalog_17031123.xml');
		//Save XML as a file
?>
